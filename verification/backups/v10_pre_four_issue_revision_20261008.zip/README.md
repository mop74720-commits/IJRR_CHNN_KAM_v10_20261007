# v10 导师意见修订稿

初版日期：2026-10-07；文字精简修订：2026-10-08。此目录是从v9另建的新版本，原v9保留。

- `main.pdf`：英文主稿，14页，含参考文献。
- `supplement.pdf`：英文补充材料，40页。两份PDF请放在同一目录，保留跨文件链接。
- `main.tex`、`supplement.tex`、`sections/`、`figures/`：可编辑稿件及全部必要图片。
- `核对说明/v10_导师意见逐项落实.md`：中文版本差异、导师要求与证据对应。
- `verification/v10_final_validation.json`：最终检查及文件身份。
- `核对说明/v10_文字精简说明_20261008.md`：本次12处文字删改及修改前备份位置。

使用原SAGE模板。重新编译时先编译supplement.tex至少两遍，再编译main.tex至少两遍；已有Python与pdflatex环境可运行reproducibility/compile_documents.py。

本包用于阅读、改稿和重新排版。完整COMSOL模型、数据、训练和区间计算资料继续保存在同级的 `IJRR_CHNN_KAM_导师意见凝练稿_20261002.zip` 中；论文Data and code availability所说的完整计算资料指该独立归档。其SHA-256为 `f335542f8eec42067bda474306ebdcb23dcca0450f132fcba7723621eab34170`。本轮没有修改这些科学数据，也没有重新运行全部实验。

本包的verification中含本轮检查结果；verify_control_algebra.py为可独立运行的SymPy代数检查，不是全部实验复现入口。其余完整实验运行环境、入口与数据见上述完整归档。
